package com.ibook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbookApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbookApplication.class, args);
	}

}
